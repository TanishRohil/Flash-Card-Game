# FlashCards
We have to run index.html to see the output.
